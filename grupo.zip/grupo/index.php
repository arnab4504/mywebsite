<?php
error_reporting(0);
require "key/open.php";
?>
