<?php if(!defined('s7V9pz')) {die();}?><?php
rt('chat');
?>