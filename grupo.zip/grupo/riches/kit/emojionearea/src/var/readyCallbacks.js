define([], function() {
    return [];
});